package database;

import java.sql.Connection;
import java.sql.DriverManager;


public class DBConnection {
    private static Connection conn = null;
    
    public static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                String url = "jdbc:mysql://localhost:3306/prms?zeroDateTimeBehavior=CONVERT_TO_NULL";
                String username = "Ashritha";
                String password = "123456";  // Your MySQL password
                
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(url, username, password);
            }
            return conn;
        } catch (Exception e) {
            System.out.println("Database Connection Error: " + e.getMessage());
            return null;
        }
    }
    
    public static void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (Exception e) {
            System.out.println("Error closing connection: " + e.getMessage());
        }
    }

    // Adding main method for testing
    public static void main(String[] args) {
        Connection testConn = getConnection();
        if (testConn != null) {
            System.out.println("Database connection successful!");
            closeConnection();
        } else {
            System.out.println("Failed to connect to database!");
        }
    }
}